/*
 *  TCC - Tiny C Compiler
 * 
 *  Copyright (c) 2001-2004 Fabrice Bellard
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS 循环 A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License 循环 more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; 若 not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#包括 "tcc.h"
#若 ONE_SOURCE
#包括 "libtcc.c"
#终若
#包括 "tcctools.c"

静态 常量 字符 help[] =
    "Tiny C Compiler "TCC_VERSION" - Copyright (C) 2001-2006 Fabrice Bellard\n"
    "Usage: tcc [选项...] [-o outfile] [-c] infile(s)...\n"
    "       tcc [选项...] -run infile [arguments...]\n"
    "General 选项:\n"
    "  -c          仅编译 - 生成对象文件\n"
    "  -o outfile  设置输出文件名\n"
    "  -run        运行编译后的源码\n"
    "  -fflag      set or reset (with 'no-' prefix) 'flag' (see tcc -hh)\n"
    "  -Wwarning   set or reset (with 'no-' prefix) '警告' (see tcc -hh)\n"
    "  -w          禁用所有警告\n"
    "  -v -vv      显示版本, 显示搜索路径或加载的文件\n"
    "  -h -hh      show this, show more help\n"
    "  -bench      显示编译统计信息\n"
    "  -           use stdin pipe as infile\n"
    "  @listfile   read arguments from listfile\n"
    "Preprocessor 选项:\n"
    "  -Idir       add 包括 path 'dir'\n"
    "  -Dsym[=val] 定义 'sym' with value 'val'\n"
    "  -Usym       undefine 'sym'\n"
    "  -E          仅预处理\n"
    "Linker 选项:\n"
    "  -Ldir       add library path 'dir'\n"
    "  -llib       link with dynamic or 静态 library 'lib'\n"
    "  -r          生成（可重定位）对象文件\n"
    "  -shared     generate a shared library/dll\n"
    "  -rdynamic   将所有全局符号导出到动态链接器\n"
    "  -soname     set name 循环 shared library to be used at runtime\n"
    "  -Wl,-opt[=val]  set linker option (see tcc -hh)\n"
    "Debugger 选项:\n"
    "  -g          生成运行时调试信息\n"
#若定义 CONFIG_TCC_BCHECK
    "  -b          编译内置内存和边界检查器(implies -g)\n"
#终若
#若定义 CONFIG_TCC_BACKTRACE
    "  -bt N       show N callers in stack traces 在堆栈跟踪中显示N个呼叫者\n"
#终若
    "Misc. 选项:\n"
    "  -x[c|a|n]   specify type of the next infile\n"
    "  -nostdinc   当 not use standard system 包括 paths\n"
    "  -nostdlib   当 not link with standard crt and libraries\n"
    "  -Bdir       set tcc's private 包括/library dir\n"
    "  -MD         生成make的依赖文件\n"
    "  -MF file    指定依赖关系文件名\n"
    "  -m32/64     defer to i386/x86_64 cross compiler\n"
    "Tools:\n"
    "  create library  : tcc -ar [rcsv] lib.a files\n"
#若定义 TCC_TARGET_PE
    "  create def file : tcc -impdef lib.dll [-v] [-o lib.def]\n"
#终若
    ;

静态 常量 字符 help2[] =
    "Tiny C Compiler "TCC_VERSION" - More 选项\n"
    "Special 选项:\n"
    "  -P -P1                        with -E: no/alternative #行 output\n"
    "  -dD -dM                       with -E: output #定义 directives\n"
    "  -pthread                      same as -D_REENTRANT and -lpthread\n"
    "  -On                           same as -D__OPTIMIZE__ 循环 n > 0\n"
    "  -Wp,-opt                      same as -opt\n"
    "  -包括 file                 包括 'file' above each input file\n"
    "  -isystem dir                  add 'dir' to system 包括 path\n"
    "  -iwithprefix dir              set tcc's private 包括/library subdir\n"
    "  -静态                       link to 静态 libraries (not recommended)\n"
    "  -dumpversion                  print version\n"
    "  -print-search-dirs            print search paths\n"
    "  -dt                           with -run/-E: 自动-定义 'test_...' macros\n"
    "Ignored 选项:\n"
    "  --param  -pedantic  -pipe  -s  -std  -traditional\n"
    "-W... warnings:\n"
    "  all                           turn on some (*) warnings\n"
    "  错误                         stop after first 警告\n"
    "  unsupported                   warn about ignored 选项, pragmas, etc.\n"
    "  write-strings                 strings are 常量\n"
    "  implicit-function-declaration warn 循环 missing prototype (*)\n"
    "-f[no-]... flags:\n"
    "  无符号-字符                 默认 字符 is 无符号\n"
    "  符号-字符                   默认 字符 is 符号\n"
    "  common                        use common section instead of bss\n"
    "  leading-underscore            decorate 外部 symbols\n"
    "  ms-extensions                 allow anonymous 结构体 in 结构体\n"
    "  dollars-in-identifiers        allow '$' in C symbols\n"
    "-m... target specific 选项:\n"
    "  ms-bitfields                  use MSVC bitfield layout\n"
#若定义 TCC_TARGET_ARM
    "  浮点-abi                     hard/softfp on arm\n"
#终若
#若定义 TCC_TARGET_X86_64
    "  no-sse                        disable floats on x86_64\n"
#终若
    "-Wl,... linker 选项:\n"
    "  -nostdlib                     当 not link with standard crt/libs\n"
    "  -[no-]whole-archive           load lib(s) fully/only as needed\n"
    "  -export-all-symbols           same as -rdynamic\n"
    "  -image-base= -Ttext=          set base address of executable\n"
    "  -section-alignment=           set section alignment in executable\n"
#若定义 TCC_TARGET_PE
    "  -file-alignment=              set PE file alignment\n"
    "  -stack=                       set PE stack reserve\n"
    "  -large-address-aware          set related PE option\n"
    "  -subsystem=[console/windows]  set PE subsystem\n"
    "  -oformat=[pe-* binary]        set executable output format\n"
    "Predefined macros:\n"
    "  tcc -E -dM - < nul\n"
#反之
    "  -rpath=                       set dynamic library search path\n"
    "  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH\n"
    "  -soname=                      set DT_SONAME elf tag\n"
    "  -Bsymbolic                    set DT_SYMBOLIC elf tag\n"
    "  -oformat=[elf32/64-* binary]  set executable output format\n"
    "  -init= -fini= -as-needed -O   (ignored)\n"
    "Predefined macros:\n"
    "  tcc -E -dM - < /dev/null\n"
#终若
    "See also the manual 循环 more details.\n"
    ;

静态 常量 字符 version[] =
    "tcc version "TCC_VERSION" ("
#若定义 TCC_TARGET_I386
        "i386"
#反之若 已定义 TCC_TARGET_X86_64
        "x86_64"
#反之若 已定义 TCC_TARGET_C67
        "C67"
#反之若 已定义 TCC_TARGET_ARM
        "ARM"
#反之若 已定义 TCC_TARGET_ARM64
        "AArch64"
#终若
#若定义 TCC_ARM_HARDFLOAT
        " Hard 浮点"
#终若
#若定义 TCC_TARGET_PE
        " Windows"
#反之若 已定义(TCC_TARGET_MACHO)
        " Darwin"
#反之若 已定义(__FreeBSD__) || 已定义(__FreeBSD_kernel__)
        " FreeBSD"
#反之
        " Linux"
#终若
    ")\n"
    ;

静态 空 print_dirs(常量 字符 *msg, 字符 **paths, 整 nb_paths)
{
    整 i;
    printf("%s:\n%s", msg, nb_paths ? "" : "  -\n");
    循环(i = 0; i < nb_paths; i++)
        printf("  %s\n", paths[i]);
}

静态 空 print_search_dirs(TCCState *s)
{
    printf("install: %s\n", s->tcc_lib_path);
    /* print_dirs("programs", NULL, 0); */
    print_dirs("包括", s->sysinclude_paths, s->nb_sysinclude_paths);
    print_dirs("libraries", s->library_paths, s->nb_library_paths);
#若未定义 TCC_TARGET_PE
    print_dirs("crt", s->crt_paths, s->nb_crt_paths);
    printf("libtcc1:\n  %s/"TCC_LIBTCC1"\n", s->tcc_lib_path);
    printf("elfinterp:\n  %s\n",  DEFAULT_ELFINTERP(s));
#终若
}

静态 空 set_environment(TCCState *s)
{
    字符 * path;

    path = getenv("C_INCLUDE_PATH");
    若(path != NULL) {
        tcc_add_include_path(s, path);
    }
    path = getenv("CPATH");
    若(path != NULL) {
        tcc_add_include_path(s, path);
    }
    path = getenv("LIBRARY_PATH");
    若(path != NULL) {
        tcc_add_library_path(s, path);
    }
}

静态 字符 *default_outputfile(TCCState *s, 常量 字符 *first_file)
{
    字符 buf[1024];
    字符 *ext;
    常量 字符 *name = "a";

    若 (first_file && strcmp(first_file, "-"))
        name = tcc_basename(first_file);
    snprintf(buf, 求大小(buf), "%s", name);
    ext = tcc_fileextension(buf);
#若定义 TCC_TARGET_PE
    若 (s->output_type == TCC_OUTPUT_DLL)
        strcpy(ext, ".dll");
    反之
    若 (s->output_type == TCC_OUTPUT_EXE)
        strcpy(ext, ".exe");
    反之
#终若
    若 (s->output_type == TCC_OUTPUT_OBJ && !s->option_r && *ext)
        strcpy(ext, ".o");
    反之
        strcpy(buf, "a.out");
    返回 tcc_strdup(buf);
}

静态 无符号 getclock_ms(空)
{
#若定义 _WIN32
    返回 GetTickCount();
#反之
    结构体 timeval tv;
    gettimeofday(&tv, NULL);
    返回 tv.tv_sec*1000 + (tv.tv_usec+500)/1000;
#终若
}

整 main(整 argc0, 字符 **argv0)
{
    TCCState *s;
    整 ret, opt, n = 0, t = 0;
    无符号 start_time = 0;
    常量 字符 *first_file;
    整 argc; 字符 **argv;
    FILE *ppfp = stdout;

redo:
    argc = argc0, argv = argv0;
    s = tcc_new();
    opt = tcc_parse_args(s, &argc, &argv, 1);

    若 ((n | t) == 0) {
        若 (opt == OPT_HELP)
            返回 printf(help), 1;
        若 (opt == OPT_HELP2)
            返回 printf(help2), 1;
        若 (opt == OPT_M32 || opt == OPT_M64)
            tcc_tool_cross(s, argv, opt); /* never returns */
        若 (s->verbose)
            printf(version);
        若 (opt == OPT_AR)
            返回 tcc_tool_ar(s, argc, argv);
#若定义 TCC_TARGET_PE
        若 (opt == OPT_IMPDEF)
            返回 tcc_tool_impdef(s, argc, argv);
#终若
        若 (opt == OPT_V)
            返回 0;
        若 (opt == OPT_PRINT_DIRS) {
            /* initialize search dirs */
            tcc_set_output_type(s, TCC_OUTPUT_MEMORY);
            print_search_dirs(s);
            返回 0;
        }

        n = s->nb_files;
        若 (n == 0)
            tcc_error("no input files\n");

        若 (s->output_type == TCC_OUTPUT_PREPROCESS) {
            若 (s->outfile) {
                ppfp = fopen(s->outfile, "w");
                若 (!ppfp)
                    tcc_error("could not write '%s'", s->outfile);
            }
        } 反之 若 (s->output_type == TCC_OUTPUT_OBJ && !s->option_r) {
            若 (s->nb_libraries)
                tcc_error("cannot specify libraries with -c");
            若 (n > 1 && s->outfile)
                tcc_error("cannot specify output file with -c many files");
        } 反之 {
            若 (s->option_pthread)
                tcc_set_options(s, "-lpthread");
        }

        若 (s->do_bench)
            start_time = getclock_ms();
    }

    set_environment(s);
    若 (s->output_type == 0)
        s->output_type = TCC_OUTPUT_EXE;
    tcc_set_output_type(s, s->output_type);
    s->ppfp = ppfp;

    若 ((s->output_type == TCC_OUTPUT_MEMORY
      || s->output_type == TCC_OUTPUT_PREPROCESS) && (s->dflag & 16))
        s->dflag |= t ? 32 : 0, s->run_test = ++t, n = s->nb_files;

    /* compile or add each files or library */
    循环 (first_file = NULL, ret = 0;;) {
        结构体 filespec *f = s->files[s->nb_files - n];
        s->filetype = f->type;
        s->alacarte_link = f->alacarte;
        若 (f->type == AFF_TYPE_LIB) {
            若 (tcc_add_library_err(s, f->name) < 0)
                ret = 1;
        } 反之 {
            若 (1 == s->verbose)
                printf("-> %s\n", f->name);
            若 (!first_file)
                first_file = f->name;
            若 (tcc_add_file(s, f->name) < 0)
                ret = 1;
        }
        s->filetype = 0;
        s->alacarte_link = 1;
        若 (--n == 0 || ret
            || (s->output_type == TCC_OUTPUT_OBJ && !s->option_r))
            打断;
    }

    若 (s->run_test) {
        t = 0;
    } 反之 若 (s->output_type == TCC_OUTPUT_PREPROCESS) {
        ;
    } 反之 若 (0 == ret) {
        若 (s->output_type == TCC_OUTPUT_MEMORY) {
#若定义 TCC_IS_NATIVE
            ret = tcc_run(s, argc, argv);
#终若
        } 反之 {
            若 (!s->outfile)
                s->outfile = default_outputfile(s, first_file);
            若 (tcc_output_file(s, s->outfile))
                ret = 1;
            反之 若 (s->gen_deps)
                gen_makedeps(s, s->outfile, s->deps_outfile);
        }
    }

    若 (s->do_bench && (n | t | ret) == 0)
        tcc_print_stats(s, getclock_ms() - start_time);
    tcc_delete(s);
    若 (ret == 0 && n)
        跳转 redo; /* compile more files with -c */
    若 (t)
        跳转 redo; /* run more tests with -dt -run */
    若 (ppfp && ppfp != stdout)
        fclose(ppfp);
    返回 ret;
}
