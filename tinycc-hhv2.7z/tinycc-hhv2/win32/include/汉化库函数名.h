#定义 main 主
#定义 printf 印
#定义 scanf 扫描