/*
 *  TCC - Tiny C Compiler - Support 循环 -run 岔路
 *
 *  Copyright (c) 2001-2004 Fabrice Bellard
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS 循环 A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License 循环 more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; 若 not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#包括 "tcc.h"

/* only native compiler supports -run */
#若定义 TCC_IS_NATIVE

#若未定义 _WIN32
# 包括 <sys/mman.h>
#终若

#若定义 CONFIG_TCC_BACKTRACE
# 若未定义 _WIN32
#  包括 <signal.h>
#  若未定义 __OpenBSD__
#   包括 <sys/ucontext.h>
#  终若
# 反之
#  定义 ucontext_t CONTEXT
# 终若
ST_DATA 整 rt_num_callers = 6;
ST_DATA 常量 字符 **rt_bound_error_msg;
ST_DATA 空 *rt_prog_main;
静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level);
静态 空 rt_error(ucontext_t *uc, 常量 字符 *fmt, ...);
静态 空 set_exception_handler(空);
#终若

静态 空 set_pages_executable(空 *ptr, 无符号 长整 length);
静态 整 tcc_relocate_ex(TCCState *s1, 空 *ptr);

#若定义 _WIN64
静态 空 *win64_add_function_table(TCCState *s1);
静态 空 win64_del_function_table(空 *);
#终若

// #定义 HAVE_SELINUX

/* ------------------------------------------------------------- */
/* 当 all relocations (needed before using tcc_get_symbol())
   Returns -1 on 错误. */

LIBTCCAPI 整 tcc_relocate(TCCState *s1, 空 *ptr)
{
    整 size;

    若 (TCC_RELOCATE_AUTO != ptr)
        返回 tcc_relocate_ex(s1, ptr);

    size = tcc_relocate_ex(s1, NULL);
    若 (size < 0)
        返回 -1;

#若定义 HAVE_SELINUX
    /* Use mmap instead of malloc 循环 Selinux. */
    ptr = mmap (NULL, size, PROT_READ|PROT_WRITE,
        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    若 (ptr == MAP_FAILED)
        tcc_error("tccrun: could not map memory");
    dynarray_add(&s1->runtime_mem, &s1->nb_runtime_mem, (空*)(addr_t)size);
#反之
    ptr = tcc_malloc(size);
#终若
    tcc_relocate_ex(s1, ptr); /* no more errors expected */
    dynarray_add(&s1->runtime_mem, &s1->nb_runtime_mem, ptr);
    返回 0;
}

ST_FUNC 空 tcc_run_free(TCCState *s1)
{
    整 i;

    循环 (i = 0; i < s1->nb_runtime_mem; ++i) {
#若定义 HAVE_SELINUX
        无符号 size = (无符号)(addr_t)s1->runtime_mem[i++];
        munmap(s1->runtime_mem[i], size);
#反之
#若定义 _WIN64
        win64_del_function_table(*(空**)s1->runtime_mem[i]);
#终若
        tcc_free(s1->runtime_mem[i]);
#终若
    }
    tcc_free(s1->runtime_mem);
}

/* launch the compiled program with the given arguments */
LIBTCCAPI 整 tcc_run(TCCState *s1, 整 argc, 字符 **argv)
{
    整 (*prog_main)(整, 字符 **);

    s1->runtime_main = "main";
    若 ((s1->dflag & 16) && !find_elf_sym(s1->symtab, s1->runtime_main))
        返回 0;
    若 (tcc_relocate(s1, TCC_RELOCATE_AUTO) < 0)
        返回 -1;
    prog_main = tcc_get_symbol_err(s1, s1->runtime_main);

#若定义 CONFIG_TCC_BACKTRACE
    若 (s1->do_debug) {
        set_exception_handler();
        rt_prog_main = prog_main;
    }
#终若

    errno = 0; /* clean errno value */

#若定义 CONFIG_TCC_BCHECK
    若 (s1->do_bounds_check) {
        空 (*bound_init)(空);
        空 (*bound_exit)(空);
        空 (*bound_new_region)(空 *p, addr_t size);
        整  (*bound_delete_region)(空 *p);
        整 i, ret;

        /* set 错误 function */
        rt_bound_error_msg = tcc_get_symbol_err(s1, "__bound_error_msg");
        /* XXX: use .init section so that it also work in binary ? */
        bound_init = tcc_get_symbol_err(s1, "__bound_init");
        bound_exit = tcc_get_symbol_err(s1, "__bound_exit");
        bound_new_region = tcc_get_symbol_err(s1, "__bound_new_region");
        bound_delete_region = tcc_get_symbol_err(s1, "__bound_delete_region");

        bound_init();
        /* mark argv area as valid */
        bound_new_region(argv, argc*求大小(argv[0]));
        循环 (i=0; i<argc; ++i)
            bound_new_region(argv[i], strlen(argv[i]) + 1);

        ret = (*prog_main)(argc, argv);

        /* unmark argv area */
        循环 (i=0; i<argc; ++i)
            bound_delete_region(argv[i]);
        bound_delete_region(argv);
        bound_exit();
        返回 ret;
    }
#终若
    返回 (*prog_main)(argc, argv);
}

#若 已定义 TCC_TARGET_I386 || 已定义 TCC_TARGET_X86_64
 #定义 RUN_SECTION_ALIGNMENT 63
#反之
 #定义 RUN_SECTION_ALIGNMENT 15
#终若

/* relocate code. 返回 -1 on 错误, required size 若 ptr is NULL,
   otherwise copy code into buffer passed by the caller */
静态 整 tcc_relocate_ex(TCCState *s1, 空 *ptr)
{
    Section *s;
    无符号 offset, length, fill, i, k;
    addr_t mem;

    若 (NULL == ptr) {
        s1->nb_errors = 0;
#若定义 TCC_TARGET_PE
        pe_output_file(s1, NULL);
#反之
        tcc_add_runtime(s1);
        relocate_common_syms();
        tcc_add_linker_symbols(s1);
        build_got_entries(s1);
#终若
        若 (s1->nb_errors)
            返回 -1;
    }

    offset = 0, mem = (addr_t)ptr;
    fill = -mem & RUN_SECTION_ALIGNMENT;
#若定义 _WIN64
    offset += 求大小 (空*);
#终若
    循环 (k = 0; k < 2; ++k) {
        循环(i = 1; i < s1->nb_sections; i++) {
            s = s1->sections[i];
            若 (0 == (s->sh_flags & SHF_ALLOC))
                继续;
            若 (k != !(s->sh_flags & SHF_EXECINSTR))
                继续;
            offset += fill;
            s->sh_addr = mem ? mem + offset : 0;
#若 0
            若 (mem)
                printf("%-16s +%02lx %p %04x\n",
                    s->name, fill, (空*)s->sh_addr, (无符号)s->data_offset);
#终若
            offset += s->data_offset;
            fill = -(mem + offset) & 15;
        }
#若 RUN_SECTION_ALIGNMENT > 15
        /* To avoid that x86 processors would reload cached instructions each time
           when data is written in the near, we need to make sure that code and data
           当 not share the same 64 byte unit */
        fill = -(mem + offset) & RUN_SECTION_ALIGNMENT;
#终若
    }

    /* relocate symbols */
    relocate_syms(s1, s1->symtab, 1);
    若 (s1->nb_errors)
        返回 -1;

    若 (0 == mem)
        返回 offset + RUN_SECTION_ALIGNMENT;

    /* relocate each section */
    循环(i = 1; i < s1->nb_sections; i++) {
        s = s1->sections[i];
        若 (s->reloc)
            relocate_section(s1, s);
    }
    relocate_plt(s1);

#若定义 _WIN64
    *(空**)ptr = win64_add_function_table(s1);
#终若

    循环(i = 1; i < s1->nb_sections; i++) {
        s = s1->sections[i];
        若 (0 == (s->sh_flags & SHF_ALLOC))
            继续;
        length = s->data_offset;
        ptr = (空*)s->sh_addr;
        若 (NULL == s->data || s->sh_type == SHT_NOBITS)
            memset(ptr, 0, length);
        反之
            memcpy(ptr, s->data, length);
        /* mark executable sections as executable in memory */
        若 (s->sh_flags & SHF_EXECINSTR)
            set_pages_executable(ptr, length);
    }
    返回 0;
}

/* ------------------------------------------------------------- */
/* allow to run code in memory */

静态 空 set_pages_executable(空 *ptr, 无符号 长整 length)
{
#若定义 _WIN32
    无符号 长整 old_protect;
    VirtualProtect(ptr, length, PAGE_EXECUTE_READWRITE, &old_protect);
#反之
    空 __clear_cache(空 *beginning, 空 *end);
    addr_t start, end;
#若未定义 PAGESIZE
# 定义 PAGESIZE 4096
#终若
    start = (addr_t)ptr & ~(PAGESIZE - 1);
    end = (addr_t)ptr + length;
    end = (end + PAGESIZE - 1) & ~(PAGESIZE - 1);
    若 (mprotect((空 *)start, end - start, PROT_READ | PROT_WRITE | PROT_EXEC))
        tcc_error("mprotect failed: did you mean to configure --with-selinux?");
# 若 已定义 TCC_TARGET_ARM || 已定义 TCC_TARGET_ARM64
    __clear_cache(ptr, (字符 *)ptr + length);
# 终若
#终若
}

#若定义 _WIN64
静态 空 *win64_add_function_table(TCCState *s1)
{
    空 *p = NULL;
    若 (s1->uw_pdata) {
        p = (空*)s1->uw_pdata->sh_addr;
        RtlAddFunctionTable(
            (RUNTIME_FUNCTION*)p,
            s1->uw_pdata->data_offset / 求大小 (RUNTIME_FUNCTION),
            text_section->sh_addr
            );
        s1->uw_pdata = NULL;
    }
    返回 p;;
}

静态 空 win64_del_function_table(空 *p)
{
    若 (p) {
        RtlDeleteFunctionTable((RUNTIME_FUNCTION*)p);
    }
}
#终若

/* ------------------------------------------------------------- */
#若定义 CONFIG_TCC_BACKTRACE

ST_FUNC 空 tcc_set_num_callers(整 n)
{
    rt_num_callers = n;
}

/* print the position in the source file of PC value 'pc' by reading
   the stabs debug information */
静态 addr_t rt_printline(addr_t wanted_pc, 常量 字符 *msg)
{
    字符 func_name[128], last_func_name[128];
    addr_t func_addr, last_pc, pc;
    常量 字符 *incl_files[INCLUDE_STACK_SIZE];
    整 incl_index, len, last_line_num, i;
    常量 字符 *str, *p;

    Stab_Sym *stab_sym = NULL, *stab_sym_end, *sym;
    整 stab_len = 0;
    字符 *stab_str = NULL;

    若 (stab_section) {
        stab_len = stab_section->data_offset;
        stab_sym = (Stab_Sym *)stab_section->data;
        stab_str = (字符 *) stabstr_section->data;
    }

    func_name[0] = '\0';
    func_addr = 0;
    incl_index = 0;
    last_func_name[0] = '\0';
    last_pc = (addr_t)-1;
    last_line_num = 1;

    若 (!stab_sym)
        跳转 no_stabs;

    stab_sym_end = (Stab_Sym*)((字符*)stab_sym + stab_len);
    循环 (sym = stab_sym + 1; sym < stab_sym_end; ++sym) {
        岔路(sym->n_type) {
            /* function start or end */
        状况 N_FUN:
            若 (sym->n_strx == 0) {
                /* we test 若 between last 行 and end of function */
                pc = sym->n_value + func_addr;
                若 (wanted_pc >= last_pc && wanted_pc < pc)
                    跳转 found;
                func_name[0] = '\0';
                func_addr = 0;
            } 反之 {
                str = stab_str + sym->n_strx;
                p = strchr(str, ':');
                若 (!p) {
                    pstrcpy(func_name, 求大小(func_name), str);
                } 反之 {
                    len = p - str;
                    若 (len > 求大小(func_name) - 1)
                        len = 求大小(func_name) - 1;
                    memcpy(func_name, str, len);
                    func_name[len] = '\0';
                }
                func_addr = sym->n_value;
            }
            打断;
            /* 行 number info */
        状况 N_SLINE:
            pc = sym->n_value + func_addr;
            若 (wanted_pc >= last_pc && wanted_pc < pc)
                跳转 found;
            last_pc = pc;
            last_line_num = sym->n_desc;
            /* XXX: slow! */
            strcpy(last_func_name, func_name);
            打断;
            /* 包括 files */
        状况 N_BINCL:
            str = stab_str + sym->n_strx;
        add_incl:
            若 (incl_index < INCLUDE_STACK_SIZE) {
                incl_files[incl_index++] = str;
            }
            打断;
        状况 N_EINCL:
            若 (incl_index > 1)
                incl_index--;
            打断;
        状况 N_SO:
            若 (sym->n_strx == 0) {
                incl_index = 0; /* end of translation unit */
            } 反之 {
                str = stab_str + sym->n_strx;
                /* 当 not add path */
                len = strlen(str);
                若 (len > 0 && str[len - 1] != '/')
                    跳转 add_incl;
            }
            打断;
        }
    }

no_stabs:
    /* second pass: we try symtab symbols (no 行 number info) */
    incl_index = 0;
    若 (symtab_section)
    {
        ElfW(Sym) *sym, *sym_end;
        整 type;

        sym_end = (ElfW(Sym) *)(symtab_section->data + symtab_section->data_offset);
        循环(sym = (ElfW(Sym) *)symtab_section->data + 1;
            sym < sym_end;
            sym++) {
            type = ELFW(ST_TYPE)(sym->st_info);
            若 (type == STT_FUNC || type == STT_GNU_IFUNC) {
                若 (wanted_pc >= sym->st_value &&
                    wanted_pc < sym->st_value + sym->st_size) {
                    pstrcpy(last_func_name, 求大小(last_func_name),
                            (字符 *) strtab_section->data + sym->st_name);
                    func_addr = sym->st_value;
                    跳转 found;
                }
            }
        }
    }
    /* did not find any info: */
    fprintf(stderr, "%s %p ???\n", msg, (空*)wanted_pc);
    fflush(stderr);
    返回 0;
 found:
    i = incl_index;
    若 (i > 0)
        fprintf(stderr, "%s:%d: ", incl_files[--i], last_line_num);
    fprintf(stderr, "%s %p", msg, (空*)wanted_pc);
    若 (last_func_name[0] != '\0')
        fprintf(stderr, " %s()", last_func_name);
    若 (--i >= 0) {
        fprintf(stderr, " (included from ");
        循环 (;;) {
            fprintf(stderr, "%s", incl_files[i]);
            若 (--i < 0)
                打断;
            fprintf(stderr, ", ");
        }
        fprintf(stderr, ")");
    }
    fprintf(stderr, "\n");
    fflush(stderr);
    返回 func_addr;
}

/* emit a run time 错误 at position 'pc' */
静态 空 rt_error(ucontext_t *uc, 常量 字符 *fmt, ...)
{
    va_list ap;
    addr_t pc;
    整 i;

    fprintf(stderr, "Runtime 错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");

    循环(i=0;i<rt_num_callers;i++) {
        若 (rt_get_caller_pc(&pc, uc, i) < 0)
            打断;
        pc = rt_printline(pc, i ? "by" : "at");
        若 (pc == (addr_t)rt_prog_main && pc)
            打断;
    }
}

/* ------------------------------------------------------------- */
#若未定义 _WIN32

/* signal handler 循环 fatal errors */
静态 空 sig_error(整 signum, siginfo_t *siginf, 空 *puc)
{
    ucontext_t *uc = puc;

    岔路(signum) {
    状况 SIGFPE:
        岔路(siginf->si_code) {
        状况 FPE_INTDIV:
        状况 FPE_FLTDIV:
            rt_error(uc, "division by zero");
            打断;
        默认:
            rt_error(uc, "floating point exception");
            打断;
        }
        打断;
    状况 SIGBUS:
    状况 SIGSEGV:
        若 (rt_bound_error_msg && *rt_bound_error_msg)
            rt_error(uc, *rt_bound_error_msg);
        反之
            rt_error(uc, "dereferencing invalid pointer");
        打断;
    状况 SIGILL:
        rt_error(uc, "illegal instruction");
        打断;
    状况 SIGABRT:
        rt_error(uc, "abort() called");
        打断;
    默认:
        rt_error(uc, "caught signal %d", signum);
        打断;
    }
    exit(255);
}

#若未定义 SA_SIGINFO
# 定义 SA_SIGINFO 0x00000004u
#终若

/* Generate a stack backtrace when a CPU exception occurs. */
静态 空 set_exception_handler(空)
{
    结构体 sigaction sigact;
    /* install TCC signal handlers to print debug info on fatal
       runtime errors */
    sigact.sa_flags = SA_SIGINFO | SA_RESETHAND;
    sigact.sa_sigaction = sig_error;
    sigemptyset(&sigact.sa_mask);
    sigaction(SIGFPE, &sigact, NULL);
    sigaction(SIGILL, &sigact, NULL);
    sigaction(SIGSEGV, &sigact, NULL);
    sigaction(SIGBUS, &sigact, NULL);
    sigaction(SIGABRT, &sigact, NULL);
}

/* ------------------------------------------------------------- */
#若定义 __i386__

/* fix 循环 glibc 2.1 */
#若未定义 REG_EIP
#定义 REG_EIP EIP
#定义 REG_EBP EBP
#终若

/* 返回 the PC at frame level 'level'. 返回 negative 若 not found */
静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level)
{
    addr_t fp;
    整 i;

    若 (level == 0) {
#若 已定义(__APPLE__)
        *paddr = uc->uc_mcontext->__ss.__eip;
#反之若 已定义(__FreeBSD__) || 已定义(__FreeBSD_kernel__) || 已定义(__DragonFly__)
        *paddr = uc->uc_mcontext.mc_eip;
#反之若 已定义(__dietlibc__)
        *paddr = uc->uc_mcontext.eip;
#反之若 已定义(__NetBSD__)
        *paddr = uc->uc_mcontext.__gregs[_REG_EIP];
#反之若 已定义(__OpenBSD__)
        *paddr = uc->sc_eip;
#反之
        *paddr = uc->uc_mcontext.gregs[REG_EIP];
#终若
        返回 0;
    } 反之 {
#若 已定义(__APPLE__)
        fp = uc->uc_mcontext->__ss.__ebp;
#反之若 已定义(__FreeBSD__) || 已定义(__FreeBSD_kernel__) || 已定义(__DragonFly__)
        fp = uc->uc_mcontext.mc_ebp;
#反之若 已定义(__dietlibc__)
        fp = uc->uc_mcontext.ebp;
#反之若 已定义(__NetBSD__)
        fp = uc->uc_mcontext.__gregs[_REG_EBP];
#反之若 已定义(__OpenBSD__)
        *paddr = uc->sc_ebp;
#反之
        fp = uc->uc_mcontext.gregs[REG_EBP];
#终若
        循环(i=1;i<level;i++) {
            /* XXX: check address validity with program info */
            若 (fp <= 0x1000 || fp >= 0xc0000000)
                返回 -1;
            fp = ((addr_t *)fp)[0];
        }
        *paddr = ((addr_t *)fp)[1];
        返回 0;
    }
}

/* ------------------------------------------------------------- */
#反之若 已定义(__x86_64__)

/* 返回 the PC at frame level 'level'. 返回 negative 若 not found */
静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level)
{
    addr_t fp;
    整 i;

    若 (level == 0) {
        /* XXX: only support linux */
#若 已定义(__APPLE__)
        *paddr = uc->uc_mcontext->__ss.__rip;
#反之若 已定义(__FreeBSD__) || 已定义(__FreeBSD_kernel__) || 已定义(__DragonFly__)
        *paddr = uc->uc_mcontext.mc_rip;
#反之若 已定义(__NetBSD__)
        *paddr = uc->uc_mcontext.__gregs[_REG_RIP];
#反之
        *paddr = uc->uc_mcontext.gregs[REG_RIP];
#终若
        返回 0;
    } 反之 {
#若 已定义(__APPLE__)
        fp = uc->uc_mcontext->__ss.__rbp;
#反之若 已定义(__FreeBSD__) || 已定义(__FreeBSD_kernel__) || 已定义(__DragonFly__)
        fp = uc->uc_mcontext.mc_rbp;
#反之若 已定义(__NetBSD__)
        fp = uc->uc_mcontext.__gregs[_REG_RBP];
#反之
        fp = uc->uc_mcontext.gregs[REG_RBP];
#终若
        循环(i=1;i<level;i++) {
            /* XXX: check address validity with program info */
            若 (fp <= 0x1000)
                返回 -1;
            fp = ((addr_t *)fp)[0];
        }
        *paddr = ((addr_t *)fp)[1];
        返回 0;
    }
}

/* ------------------------------------------------------------- */
#反之若 已定义(__arm__)

/* 返回 the PC at frame level 'level'. 返回 negative 若 not found */
静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level)
{
    addr_t fp, sp;
    整 i;

    若 (level == 0) {
        /* XXX: only supports linux */
#若 已定义(__linux__)
        *paddr = uc->uc_mcontext.arm_pc;
#反之
        返回 -1;
#终若
        返回 0;
    } 反之 {
#若 已定义(__linux__)
        fp = uc->uc_mcontext.arm_fp;
        sp = uc->uc_mcontext.arm_sp;
        若 (sp < 0x1000)
            sp = 0x1000;
#反之
        返回 -1;
#终若
        /* XXX: specific to tinycc stack frames */
        若 (fp < sp + 12 || fp & 3)
            返回 -1;
        循环(i = 1; i < level; i++) {
            sp = ((addr_t *)fp)[-2];
            若 (sp < fp || sp - fp > 16 || sp & 3)
                返回 -1;
            fp = ((addr_t *)fp)[-3];
            若 (fp <= sp || fp - sp < 12 || fp & 3)
                返回 -1;
        }
        /* XXX: check address validity with program info */
        *paddr = ((addr_t *)fp)[-1];
        返回 0;
    }
}

/* ------------------------------------------------------------- */
#反之若 已定义(__aarch64__)

静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level)
{
    若 (level < 0)
        返回 -1;
    反之 若 (level == 0) {
        *paddr = uc->uc_mcontext.pc;
        返回 0;
    }
    反之 {
        addr_t *fp = (addr_t *)uc->uc_mcontext.regs[29];
        整 i;
        循环 (i = 1; i < level; i++)
            fp = (addr_t *)fp[0];
        *paddr = fp[1];
        返回 0;
    }
}

/* ------------------------------------------------------------- */
#反之

#警告 add arch specific rt_get_caller_pc()
静态 整 rt_get_caller_pc(addr_t *paddr, ucontext_t *uc, 整 level)
{
    返回 -1;
}

#终若 /* !__i386__ */

/* ------------------------------------------------------------- */
#反之 /* WIN32 */

静态 长整 __stdcall cpu_exception_handler(EXCEPTION_POINTERS *ex_info)
{
    EXCEPTION_RECORD *er = ex_info->ExceptionRecord;
    CONTEXT *uc = ex_info->ContextRecord;
    岔路 (er->ExceptionCode) {
    状况 EXCEPTION_ACCESS_VIOLATION:
        若 (rt_bound_error_msg && *rt_bound_error_msg)
            rt_error(uc, *rt_bound_error_msg);
        反之
	    rt_error(uc, "access violation");
        打断;
    状况 EXCEPTION_STACK_OVERFLOW:
        rt_error(uc, "stack overflow");
        打断;
    状况 EXCEPTION_INT_DIVIDE_BY_ZERO:
        rt_error(uc, "division by zero");
        打断;
    默认:
        rt_error(uc, "exception caught");
        打断;
    }
    返回 EXCEPTION_EXECUTE_HANDLER;
}

/* Generate a stack backtrace when a CPU exception occurs. */
静态 空 set_exception_handler(空)
{
    SetUnhandledExceptionFilter(cpu_exception_handler);
}

/* 返回 the PC at frame level 'level'. 返回 non zero 若 not found */
静态 整 rt_get_caller_pc(addr_t *paddr, CONTEXT *uc, 整 level)
{
    addr_t fp, pc;
    整 i;
#若定义 _WIN64
    pc = uc->Rip;
    fp = uc->Rbp;
#反之
    pc = uc->Eip;
    fp = uc->Ebp;
#终若
    若 (level > 0) {
        循环(i=1;i<level;i++) {
	    /* XXX: check address validity with program info */
	    若 (fp <= 0x1000 || fp >= 0xc0000000)
		返回 -1;
	    fp = ((addr_t*)fp)[0];
	}
        pc = ((addr_t*)fp)[1];
    }
    *paddr = pc;
    返回 0;
}

#终若 /* _WIN32 */
#终若 /* CONFIG_TCC_BACKTRACE */
/* ------------------------------------------------------------- */
#若定义 CONFIG_TCC_STATIC

/* dummy function 循环 profiling */
ST_FUNC 空 *dlopen(常量 字符 *filename, 整 flag)
{
    返回 NULL;
}

ST_FUNC 空 dlclose(空 *p)
{
}

ST_FUNC 常量 字符 *dlerror(空)
{
    返回 "错误";
}

类型定义 结构体 TCCSyms {
    字符 *str;
    空 *ptr;
} TCCSyms;


/* add the symbol you want here 若 no dynamic linking is done */
静态 TCCSyms tcc_syms[] = {
#若 !已定义(CONFIG_TCCBOOT)
#定义 TCCSYM(a) { #a, &a, },
    TCCSYM(printf)
    TCCSYM(fprintf)
    TCCSYM(fopen)
    TCCSYM(fclose)
#取消定义 TCCSYM
#终若
    { NULL, NULL },
};

ST_FUNC 空 *dlsym(空 *handle, 常量 字符 *symbol)
{
    TCCSyms *p;
    p = tcc_syms;
    重复 (p->str != NULL) {
        若 (!strcmp(p->str, symbol))
            返回 p->ptr;
        p++;
    }
    返回 NULL;
}

#终若 /* CONFIG_TCC_STATIC */
#终若 /* TCC_IS_NATIVE */
/* ------------------------------------------------------------- */
