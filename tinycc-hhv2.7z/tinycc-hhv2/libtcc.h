#若未定义 LIBTCC_H
#定义 LIBTCC_H

#若未定义 LIBTCCAPI
# 定义 LIBTCCAPI
#终若

#若定义 __cplusplus
外部 "C" {
#终若

结构体 TCCState;

类型定义 结构体 TCCState TCCState;

/* create a new TCC compilation context */
LIBTCCAPI TCCState *tcc_new(空);

/* free a TCC compilation context */
LIBTCCAPI 空 tcc_delete(TCCState *s);

/* set CONFIG_TCCDIR at runtime */
LIBTCCAPI 空 tcc_set_lib_path(TCCState *s, 常量 字符 *path);

/* set 错误/警告 display callback */
LIBTCCAPI 空 tcc_set_error_func(TCCState *s, 空 *error_opaque,
    空 (*error_func)(空 *opaque, 常量 字符 *msg));

/* set options as from command 行 (multiple supported) */
LIBTCCAPI 空 tcc_set_options(TCCState *s, 常量 字符 *str);

/*****************************/
/* preprocessor */

/* add 包括 path */
LIBTCCAPI 整 tcc_add_include_path(TCCState *s, 常量 字符 *pathname);

/* add in system 包括 path */
LIBTCCAPI 整 tcc_add_sysinclude_path(TCCState *s, 常量 字符 *pathname);

/* 定义 preprocessor symbol 'sym'. Can put optional value */
LIBTCCAPI 空 tcc_define_symbol(TCCState *s, 常量 字符 *sym, 常量 字符 *value);

/* undefine preprocess symbol 'sym' */
LIBTCCAPI 空 tcc_undefine_symbol(TCCState *s, 常量 字符 *sym);

/*****************************/
/* compiling */

/* add a file (C file, dll, object, library, ld script). 返回 -1 若 错误. */
LIBTCCAPI 整 tcc_add_file(TCCState *s, 常量 字符 *filename);

/* compile a string containing a C source. 返回 -1 若 错误. */
LIBTCCAPI 整 tcc_compile_string(TCCState *s, 常量 字符 *buf);

/*****************************/
/* linking commands */

/* set output type. MUST BE CALLED before any compilation */
LIBTCCAPI 整 tcc_set_output_type(TCCState *s, 整 output_type);
#定义 TCC_OUTPUT_MEMORY   1 /* output will be run in memory (默认) */
#定义 TCC_OUTPUT_EXE      2 /* executable file */
#定义 TCC_OUTPUT_DLL      3 /* dynamic library */
#定义 TCC_OUTPUT_OBJ      4 /* object file */
#定义 TCC_OUTPUT_PREPROCESS 5 /* only preprocess (used internally) */

/* equivalent to -Lpath option */
LIBTCCAPI 整 tcc_add_library_path(TCCState *s, 常量 字符 *pathname);

/* the library name is the same as the argument of the '-l' option */
LIBTCCAPI 整 tcc_add_library(TCCState *s, 常量 字符 *libraryname);

/* add a symbol to the compiled program */
LIBTCCAPI 整 tcc_add_symbol(TCCState *s, 常量 字符 *name, 常量 空 *val);

/* output an executable, library or object file. 当 NOT call
   tcc_relocate() before. */
LIBTCCAPI 整 tcc_output_file(TCCState *s, 常量 字符 *filename);

/* link and run main() function and 返回 its value. 当 NOT call
   tcc_relocate() before. */
LIBTCCAPI 整 tcc_run(TCCState *s, 整 argc, 字符 **argv);

/* 当 all relocations (needed before using tcc_get_symbol()) */
LIBTCCAPI 整 tcc_relocate(TCCState *s1, 空 *ptr);
/* possible values 循环 'ptr':
   - TCC_RELOCATE_AUTO : Allocate and manage memory internally
   - NULL              : 返回 required memory size 循环 the step below
   - memory address    : copy code to memory passed by the caller
   returns -1 若 错误. */
#定义 TCC_RELOCATE_AUTO (空*)1

/* 返回 symbol value or NULL 若 not found */
LIBTCCAPI 空 *tcc_get_symbol(TCCState *s, 常量 字符 *name);

#若定义 __cplusplus
}
#终若

#终若
