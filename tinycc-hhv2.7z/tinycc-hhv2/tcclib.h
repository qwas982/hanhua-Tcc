/* Simple libc header 循环 TCC 
 * 
 * Add any function you want from the libc there. This file is here
 * only 循环 your convenience so that you 当 not need to put the whole
 * glibc 包括 files on your floppy disk 
 */
#若未定义 _TCCLIB_H
#定义 _TCCLIB_H

#包括 <stddef.h>
#包括 <stdarg.h>

/* stdlib.h */
空 *calloc(size_t nmemb, size_t size);
空 *malloc(size_t size);
空 free(空 *ptr);
空 *realloc(空 *ptr, size_t size);
整 atoi(常量 字符 *nptr);
长整 整 strtol(常量 字符 *nptr, 字符 **endptr, 整 base);
无符号 长整 整 strtoul(常量 字符 *nptr, 字符 **endptr, 整 base);
空 exit(整);

/* stdio.h */
类型定义 结构体 __FILE FILE;
#定义 EOF (-1)
外部 FILE *stdin;
外部 FILE *stdout;
外部 FILE *stderr;
FILE *fopen(常量 字符 *path, 常量 字符 *mode);
FILE *fdopen(整 fildes, 常量 字符 *mode);
FILE *freopen(常量  字符 *path, 常量 字符 *mode, FILE *stream);
整 fclose(FILE *stream);
size_t  fread(空 *ptr, size_t size, size_t nmemb, FILE *stream);
size_t  fwrite(空 *ptr, size_t size, size_t nmemb, FILE *stream);
整 fgetc(FILE *stream);
字符 *fgets(字符 *s, 整 size, FILE *stream);
整 getc(FILE *stream);
整 getchar(空);
字符 *gets(字符 *s);
整 ungetc(整 c, FILE *stream);
整 fflush(FILE *stream);
整 putchar (整 c);

整 printf(常量 字符 *format, ...);
整 fprintf(FILE *stream, 常量 字符 *format, ...);
整 sprintf(字符 *str, 常量 字符 *format, ...);
整 snprintf(字符 *str, size_t size, 常量  字符  *format, ...);
整 asprintf(字符 **strp, 常量 字符 *format, ...);
整 dprintf(整 fd, 常量 字符 *format, ...);
整 vprintf(常量 字符 *format, va_list ap);
整 vfprintf(FILE  *stream,  常量  字符 *format, va_list ap);
整 vsprintf(字符 *str, 常量 字符 *format, va_list ap);
整 vsnprintf(字符 *str, size_t size, 常量 字符  *format, va_list ap);
整 vasprintf(字符  **strp,  常量  字符 *format, va_list ap);
整 vdprintf(整 fd, 常量 字符 *format, va_list ap);

空 perror(常量 字符 *s);

/* string.h */
字符 *strcat(字符 *dest, 常量 字符 *src);
字符 *strchr(常量 字符 *s, 整 c);
字符 *strrchr(常量 字符 *s, 整 c);
字符 *strcpy(字符 *dest, 常量 字符 *src);
空 *memcpy(空 *dest, 常量 空 *src, size_t n);
空 *memmove(空 *dest, 常量 空 *src, size_t n);
空 *memset(空 *s, 整 c, size_t n);
字符 *strdup(常量 字符 *s);
size_t strlen(常量 字符 *s);

/* dlfcn.h */
#定义 RTLD_LAZY       0x001
#定义 RTLD_NOW        0x002
#定义 RTLD_GLOBAL     0x100

空 *dlopen(常量 字符 *filename, 整 flag);
常量 字符 *dlerror(空);
空 *dlsym(空 *handle, 字符 *symbol);
整 dlclose(空 *handle);

#终若 /* _TCCLIB_H */
