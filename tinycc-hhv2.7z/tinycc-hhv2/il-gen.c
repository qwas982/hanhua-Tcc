/*
 *  CIL code generator 循环 TCC
 * 
 *  Copyright (c) 2002 Fabrice Bellard
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS 循环 A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License 循环 more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; 若 not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#错误 this code has bit-rotted since 2003

/* number of available registers */
#定义 NB_REGS             3

/* a 寄存器 can belong to several classes. The classes must be
   sorted from more general to more precise (see gv2() code which does
   assumptions on it). */
#定义 RC_ST      0x0001  /* any stack entry */
#定义 RC_ST0     0x0002  /* top of stack */
#定义 RC_ST1     0x0004  /* top - 1 */

#定义 RC_INT     RC_ST
#定义 RC_FLOAT   RC_ST
#定义 RC_IRET    RC_ST0 /* function 返回: integer 寄存器 */
#定义 RC_LRET    RC_ST0 /* function 返回: second integer 寄存器 */
#定义 RC_FRET    RC_ST0 /* function 返回: 浮点 寄存器 */

/* pretty names 循环 the registers */
枚举 {
    REG_ST0 = 0,
    REG_ST1,
    REG_ST2,
};

常量 整 reg_classes[NB_REGS] = {
    /* ST0 */ RC_ST | RC_ST0,
    /* ST1 */ RC_ST | RC_ST1,
    /* ST2 */ RC_ST,
};

/* 返回 registers 循环 function */
#定义 REG_IRET REG_ST0 /* single word 整 返回 寄存器 */
#定义 REG_LRET REG_ST0 /* second word 返回 寄存器 (循环 长整 长整) */
#定义 REG_FRET REG_ST0 /* 浮点 返回 寄存器 */

/* 已定义 若 function parameters must be evaluated in reverse order */
/* #定义 INVERT_FUNC_PARAMS */

/* 已定义 若 structures are passed as pointers. Otherwise structures
   are directly pushed on stack. */
/* #定义 FUNC_STRUCT_PARAM_AS_PTR */

/* pointer size, in bytes */
#定义 PTR_SIZE 4

/* 长整 双浮 size and alignment, in bytes */
#定义 LDOUBLE_SIZE  8
#定义 LDOUBLE_ALIGN 8

/* function call context */
类型定义 结构体 GFuncContext {
    整 func_call; /* func call type (FUNC_STDCALL or FUNC_CDECL) */
} GFuncContext;

/******************************************************/
/* opcode definitions */

#定义 IL_OP_PREFIX 0xFE

枚举 ILOPCodes {
#定义 OP(name, str, n) IL_OP_ ## name = n,
#包括 "il-opcodes.h"
#取消定义 OP
};

字符 *il_opcodes_str[] = {
#定义 OP(name, str, n) [n] = str,
#包括 "il-opcodes.h"
#取消定义 OP
};

/******************************************************/

/* arguments variable numbers start from there */
#定义 ARG_BASE 0x70000000

静态 FILE *il_outfile;

静态 空 out_byte(整 c)
{
    *(字符 *)ind++ = c;
}

静态 空 out_le32(整 c)
{
    out_byte(c);
    out_byte(c >> 8);
    out_byte(c >> 16);
    out_byte(c >> 24);
}

静态 空 init_outfile(空)
{
    若 (!il_outfile) {
        il_outfile = stdout;
        fprintf(il_outfile, 
                ".assembly 外部 mscorlib\n"
                "{\n"
                ".ver 1:0:2411:0\n"
                "}\n\n");
    }
}

静态 空 out_op1(整 op)
{
    若 (op & 0x100)
        out_byte(IL_OP_PREFIX);
    out_byte(op & 0xff);
}

/* output an opcode with prefix */
静态 空 out_op(整 op)
{
    out_op1(op);
    fprintf(il_outfile, " %s\n", il_opcodes_str[op]);
}

静态 空 out_opb(整 op, 整 c)
{
    out_op1(op);
    out_byte(c);
    fprintf(il_outfile, " %s %d\n", il_opcodes_str[op], c);
}

静态 空 out_opi(整 op, 整 c)
{
    out_op1(op);
    out_le32(c);
    fprintf(il_outfile, " %s 0x%x\n", il_opcodes_str[op], c);
}

/* XXX: not complete */
静态 空 il_type_to_str(字符 *buf, 整 buf_size, 
                           整 t, 常量 字符 *varstr)
{
    整 bt;
    Sym *s, *sa;
    字符 buf1[256];
    常量 字符 *tstr;

    t = t & VT_TYPE;
    bt = t & VT_BTYPE;
    buf[0] = '\0';
    若 (t & VT_UNSIGNED)
        pstrcat(buf, buf_size, "无符号 ");
    岔路(bt) {
    状况 VT_VOID:
        tstr = "空";
        跳转 add_tstr;
    状况 VT_BOOL:
        tstr = "布尔";
        跳转 add_tstr;
    状况 VT_BYTE:
        tstr = "int8";
        跳转 add_tstr;
    状况 VT_SHORT:
        tstr = "int16";
        跳转 add_tstr;
    状况 VT_ENUM:
    状况 VT_INT:
    状况 VT_LONG:
        tstr = "int32";
        跳转 add_tstr;
    状况 VT_LLONG:
        tstr = "int64";
        跳转 add_tstr;
    状况 VT_FLOAT:
        tstr = "float32";
        跳转 add_tstr;
    状况 VT_DOUBLE:
    状况 VT_LDOUBLE:
        tstr = "float64";
    add_tstr:
        pstrcat(buf, buf_size, tstr);
        打断;
    状况 VT_STRUCT:
        tcc_error("structures not handled yet");
        打断;
    状况 VT_FUNC:
        s = sym_find((无符号)t >> VT_STRUCT_SHIFT);
        il_type_to_str(buf, buf_size, s->t, varstr);
        pstrcat(buf, buf_size, "(");
        sa = s->next;
        重复 (sa != NULL) {
            il_type_to_str(buf1, 求大小(buf1), sa->t, NULL);
            pstrcat(buf, buf_size, buf1);
            sa = sa->next;
            若 (sa)
                pstrcat(buf, buf_size, ", ");
        }
        pstrcat(buf, buf_size, ")");
        跳转 no_var;
    状况 VT_PTR:
        s = sym_find((无符号)t >> VT_STRUCT_SHIFT);
        pstrcpy(buf1, 求大小(buf1), "*");
        若 (varstr)
            pstrcat(buf1, 求大小(buf1), varstr);
        il_type_to_str(buf, buf_size, s->t, buf1);
        跳转 no_var;
    }
    若 (varstr) {
        pstrcat(buf, buf_size, " ");
        pstrcat(buf, buf_size, varstr);
    }
 no_var: ;
}


/* patch relocation entry with value 'val' */
空 greloc_patch1(Reloc *p, 整 val)
{
}

/* output a symbol and patch all calls to it */
空 gsym_addr(t, a)
{
}

/* output jump and 返回 symbol */
静态 整 out_opj(整 op, 整 c)
{
    out_op1(op);
    out_le32(0);
    若 (c == 0) {
        c = ind - (整)cur_text_section->data;
    }
    fprintf(il_outfile, " %s L%d\n", il_opcodes_str[op], c);
    返回 c;
}

空 gsym(整 t)
{
    fprintf(il_outfile, "L%d:\n", t);
}

/* load 'r' from value 'sv' */
空 load(整 r, SValue *sv)
{
    整 v, fc, ft;

    v = sv->r & VT_VALMASK;
    fc = sv->c.i;
    ft = sv->t;

    若 (sv->r & VT_LVAL) {
        若 (v == VT_LOCAL) {
            若 (fc >= ARG_BASE) {
                fc -= ARG_BASE;
                若 (fc >= 0 && fc <= 4) {
                    out_op(IL_OP_LDARG_0 + fc);
                } 反之 若 (fc <= 0xff) {
                    out_opb(IL_OP_LDARG_S, fc);
                } 反之 {
                    out_opi(IL_OP_LDARG, fc);
                }
            } 反之 {
                若 (fc >= 0 && fc <= 4) {
                    out_op(IL_OP_LDLOC_0 + fc);
                } 反之 若 (fc <= 0xff) {
                    out_opb(IL_OP_LDLOC_S, fc);
                } 反之 {
                    out_opi(IL_OP_LDLOC, fc);
                }
            }
        } 反之 若 (v == VT_CONST) {
                /* XXX: handle globals */
                out_opi(IL_OP_LDSFLD, 0);
        } 反之 {
            若 ((ft & VT_BTYPE) == VT_FLOAT) {
                out_op(IL_OP_LDIND_R4);
            } 反之 若 ((ft & VT_BTYPE) == VT_DOUBLE) {
                out_op(IL_OP_LDIND_R8);
            } 反之 若 ((ft & VT_BTYPE) == VT_LDOUBLE) {
                out_op(IL_OP_LDIND_R8);
            } 反之 若 ((ft & VT_TYPE) == VT_BYTE)
                out_op(IL_OP_LDIND_I1);
            反之 若 ((ft & VT_TYPE) == (VT_BYTE | VT_UNSIGNED))
                out_op(IL_OP_LDIND_U1);
            反之 若 ((ft & VT_TYPE) == VT_SHORT)
                out_op(IL_OP_LDIND_I2);
            反之 若 ((ft & VT_TYPE) == (VT_SHORT | VT_UNSIGNED))
                out_op(IL_OP_LDIND_U2);
            反之
                out_op(IL_OP_LDIND_I4);
        } 
    } 反之 {
        若 (v == VT_CONST) {
            /* XXX: handle globals */
            若 (fc >= -1 && fc <= 8) {
                out_op(IL_OP_LDC_I4_M1 + fc + 1); 
            } 反之 {
                out_opi(IL_OP_LDC_I4, fc);
            }
        } 反之 若 (v == VT_LOCAL) {
            若 (fc >= ARG_BASE) {
                fc -= ARG_BASE;
                若 (fc <= 0xff) {
                    out_opb(IL_OP_LDARGA_S, fc);
                } 反之 {
                    out_opi(IL_OP_LDARGA, fc);
                }
            } 反之 {
                若 (fc <= 0xff) {
                    out_opb(IL_OP_LDLOCA_S, fc);
                } 反之 {
                    out_opi(IL_OP_LDLOCA, fc);
                }
            }
        } 反之 {
            /* XXX: 当 it */
        }
    }
}

/* store 寄存器 'r' in lvalue 'v' */
空 store(整 r, SValue *sv)
{
    整 v, fc, ft;

    v = sv->r & VT_VALMASK;
    fc = sv->c.i;
    ft = sv->t;
    若 (v == VT_LOCAL) {
        若 (fc >= ARG_BASE) {
            fc -= ARG_BASE;
            /* XXX: check IL arg store semantics */
            若 (fc <= 0xff) {
                out_opb(IL_OP_STARG_S, fc);
            } 反之 {
                out_opi(IL_OP_STARG, fc);
            }
        } 反之 {
            若 (fc >= 0 && fc <= 4) {
                out_op(IL_OP_STLOC_0 + fc);
            } 反之 若 (fc <= 0xff) {
                out_opb(IL_OP_STLOC_S, fc);
            } 反之 {
                out_opi(IL_OP_STLOC, fc);
            }
        }
    } 反之 若 (v == VT_CONST) {
        /* XXX: handle globals */
        out_opi(IL_OP_STSFLD, 0);
    } 反之 {
        若 ((ft & VT_BTYPE) == VT_FLOAT)
            out_op(IL_OP_STIND_R4);
        反之 若 ((ft & VT_BTYPE) == VT_DOUBLE)
            out_op(IL_OP_STIND_R8);
        反之 若 ((ft & VT_BTYPE) == VT_LDOUBLE)
            out_op(IL_OP_STIND_R8);
        反之 若 ((ft & VT_BTYPE) == VT_BYTE)
            out_op(IL_OP_STIND_I1);
        反之 若 ((ft & VT_BTYPE) == VT_SHORT)
            out_op(IL_OP_STIND_I2);
        反之
            out_op(IL_OP_STIND_I4);
    }
}

/* start function call and 返回 function call context */
空 gfunc_start(GFuncContext *c, 整 func_call)
{
    c->func_call = func_call;
}

/* push function parameter which is in (vtop->t, vtop->c). Stack entry
   is then popped. */
空 gfunc_param(GFuncContext *c)
{
    若 ((vtop->t & VT_BTYPE) == VT_STRUCT) {
        tcc_error("structures passed as value not handled yet");
    } 反之 {
        /* simply push on stack */
        gv(RC_ST0);
    }
    vtop--;
}

/* generate function call with address in (vtop->t, vtop->c) and free function
   context. Stack entry is popped */
空 gfunc_call(GFuncContext *c)
{
    字符 buf[1024];

    若 ((vtop->r & (VT_VALMASK | VT_LVAL)) == VT_CONST) {
        /* XXX: more info needed from tcc */
        il_type_to_str(buf, 求大小(buf), vtop->t, "xxx");
        fprintf(il_outfile, " call %s\n", buf);
    } 反之 {
        /* indirect call */
        gv(RC_INT);
        il_type_to_str(buf, 求大小(buf), vtop->t, NULL);
        fprintf(il_outfile, " calli %s\n", buf);
    }
    vtop--;
}

/* generate function prolog of type 't' */
空 gfunc_prolog(整 t)
{
    整 addr, u, func_call;
    Sym *sym;
    字符 buf[1024];

    init_outfile();

    /* XXX: pass function name to gfunc_prolog */
    il_type_to_str(buf, 求大小(buf), t, funcname);
    fprintf(il_outfile, ".method 静态 %s il managed\n", buf);
    fprintf(il_outfile, "{\n");
    /* XXX: cannot 当 better now */
    fprintf(il_outfile, " .maxstack %d\n", NB_REGS);
    fprintf(il_outfile, " .locals (int32, int32, int32, int32, int32, int32, int32, int32)\n");
    
    若 (!strcmp(funcname, "main"))
        fprintf(il_outfile, " .entrypoint\n");
        
    sym = sym_find((无符号)t >> VT_STRUCT_SHIFT);
    func_call = sym->r;

    addr = ARG_BASE;
    /* 若 the function returns a structure, then add an
       implicit pointer parameter */
    func_vt = sym->t;
    func_var = (sym->c == FUNC_ELLIPSIS);
    若 ((func_vt & VT_BTYPE) == VT_STRUCT) {
        func_vc = addr;
        addr++;
    }
    /* 定义 parameters */
    重复 ((sym = sym->next) != NULL) {
        u = sym->t;
        sym_push(sym->v & ~SYM_FIELD, u,
                 VT_LOCAL | lvalue_type(sym->type.t), addr);
        addr++;
    }
}

/* generate function epilog */
空 gfunc_epilog(空)
{
    out_op(IL_OP_RET);
    fprintf(il_outfile, "}\n\n");
}

/* generate a jump to a 标签 */
整 gjmp(整 t)
{
    返回 out_opj(IL_OP_BR, t);
}

/* generate a jump to a fixed address */
空 gjmp_addr(整 a)
{
    /* XXX: handle syms */
    out_opi(IL_OP_BR, a);
}

/* generate a test. set 'inv' to invert test. Stack entry is popped */
整 gtst(整 inv, 整 t)
{
    整 v, *p, c;

    v = vtop->r & VT_VALMASK;
    若 (v == VT_CMP) {
        c = vtop->c.i ^ inv;
        岔路(c) {
        状况 TOK_EQ:
            c = IL_OP_BEQ;
            打断;
        状况 TOK_NE:
            c = IL_OP_BNE_UN;
            打断;
        状况 TOK_LT:
            c = IL_OP_BLT;
            打断;
        状况 TOK_LE:
            c = IL_OP_BLE;
            打断;
        状况 TOK_GT:
            c = IL_OP_BGT;
            打断;
        状况 TOK_GE:
            c = IL_OP_BGE;
            打断;
        状况 TOK_ULT:
            c = IL_OP_BLT_UN;
            打断;
        状况 TOK_ULE:
            c = IL_OP_BLE_UN;
            打断;
        状况 TOK_UGT:
            c = IL_OP_BGT_UN;
            打断;
        状况 TOK_UGE:
            c = IL_OP_BGE_UN;
            打断;
        }
        t = out_opj(c, t);
    } 反之 若 (v == VT_JMP || v == VT_JMPI) {
        /* && or || optimization */
        若 ((v & 1) == inv) {
            /* insert vtop->c jump list in t */
            p = &vtop->c.i;
            重复 (*p != 0)
                p = (整 *)*p;
            *p = t;
            t = vtop->c.i;
        } 反之 {
            t = gjmp(t);
            gsym(vtop->c.i);
        }
    }
    vtop--;
    返回 t;
}

/* generate an integer binary operation */
空 gen_opi(整 op)
{
    gv2(RC_ST1, RC_ST0);
    岔路(op) {
    状况 '+':
        out_op(IL_OP_ADD);
        跳转 std_op;
    状况 '-':
        out_op(IL_OP_SUB);
        跳转 std_op;
    状况 '&':
        out_op(IL_OP_AND);
        跳转 std_op;
    状况 '^':
        out_op(IL_OP_XOR);
        跳转 std_op;
    状况 '|':
        out_op(IL_OP_OR);
        跳转 std_op;
    状况 '*':
        out_op(IL_OP_MUL);
        跳转 std_op;
    状况 TOK_SHL:
        out_op(IL_OP_SHL);
        跳转 std_op;
    状况 TOK_SHR:
        out_op(IL_OP_SHR_UN);
        跳转 std_op;
    状况 TOK_SAR:
        out_op(IL_OP_SHR);
        跳转 std_op;
    状况 '/':
    状况 TOK_PDIV:
        out_op(IL_OP_DIV);
        跳转 std_op;
    状况 TOK_UDIV:
        out_op(IL_OP_DIV_UN);
        跳转 std_op;
    状况 '%':
        out_op(IL_OP_REM);
        跳转 std_op;
    状况 TOK_UMOD:
        out_op(IL_OP_REM_UN);
    std_op:
        vtop--;
        vtop[0].r = REG_ST0;
        打断;
    状况 TOK_EQ:
    状况 TOK_NE:
    状况 TOK_LT:
    状况 TOK_LE:
    状况 TOK_GT:
    状况 TOK_GE:
    状况 TOK_ULT:
    状况 TOK_ULE:
    状况 TOK_UGT:
    状况 TOK_UGE:
        vtop--;
        vtop[0].r = VT_CMP;
        vtop[0].c.i = op;
        打断;
    }
}

/* generate a floating point operation 'v = t1 op t2' instruction. The
   two operands are guaranteed to have the same floating point type */
空 gen_opf(整 op)
{
    /* same as integer */
    gen_opi(op);
}

/* convert integers to fp 't' type. Must handle '整', '无符号 整'
   and '长整 长整' cases. */
空 gen_cvt_itof(整 t)
{
    gv(RC_ST0);
    若 (t == VT_FLOAT)
        out_op(IL_OP_CONV_R4);
    反之
        out_op(IL_OP_CONV_R8);
}

/* convert fp to 整 't' type */
/* XXX: handle 长整 长整 状况 */
空 gen_cvt_ftoi(整 t)
{
    gv(RC_ST0);
    岔路(t) {
    状况 VT_INT | VT_UNSIGNED:
        out_op(IL_OP_CONV_U4);
        打断;
    状况 VT_LLONG:
        out_op(IL_OP_CONV_I8);
        打断;
    状况 VT_LLONG | VT_UNSIGNED:
        out_op(IL_OP_CONV_U8);
        打断;
    默认:
        out_op(IL_OP_CONV_I4);
        打断;
    }
}

/* convert from one floating point type to another */
空 gen_cvt_ftof(整 t)
{
    gv(RC_ST0);
    若 (t == VT_FLOAT) {
        out_op(IL_OP_CONV_R4);
    } 反之 {
        out_op(IL_OP_CONV_R8);
    }
}

/* end of CIL code generator */
/*************************************************************/

