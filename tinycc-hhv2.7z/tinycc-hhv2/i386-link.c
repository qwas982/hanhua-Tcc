#若定义 TARGET_DEFS_ONLY

#定义 EM_TCC_TARGET EM_386

/* relocation type 循环 32 bit data relocation */
#定义 R_DATA_32   R_386_32
#定义 R_DATA_PTR  R_386_32
#定义 R_JMP_SLOT  R_386_JMP_SLOT
#定义 R_GLOB_DAT  R_386_GLOB_DAT
#定义 R_COPY      R_386_COPY
#定义 R_RELATIVE  R_386_RELATIVE

#定义 R_NUM       R_386_NUM

#定义 ELF_START_ADDR 0x08048000
#定义 ELF_PAGE_SIZE  0x1000

#定义 PCRELATIVE_DLLPLT 0
#定义 RELOCATE_DLLPLT 0

#反之 /* !TARGET_DEFS_ONLY */

#包括 "tcc.h"

/* Returns 1 循环 a code relocation, 0 循环 a data relocation. 循环 unknown
   relocations, returns -1. */
整 code_reloc (整 reloc_type)
{
    岔路 (reloc_type) {
	状况 R_386_RELATIVE:
	状况 R_386_16:
        状况 R_386_32:
	状况 R_386_GOTPC:
	状况 R_386_GOTOFF:
	状况 R_386_GOT32:
	状况 R_386_GOT32X:
	状况 R_386_GLOB_DAT:
	状况 R_386_COPY:
            返回 0;

	状况 R_386_PC16:
	状况 R_386_PC32:
	状况 R_386_PLT32:
	状况 R_386_JMP_SLOT:
            返回 1;
    }

    tcc_error ("Unknown relocation type: %d", reloc_type);
    返回 -1;
}

/* Returns an enumerator to describe whether and when the relocation needs a
   GOT and/or PLT entry to be created. See tcc.h 循环 a description of the
   different values. */
整 gotplt_entry_type (整 reloc_type)
{
    岔路 (reloc_type) {
	状况 R_386_RELATIVE:
	状况 R_386_16:
	状况 R_386_GLOB_DAT:
	状况 R_386_JMP_SLOT:
	状况 R_386_COPY:
            返回 NO_GOTPLT_ENTRY;

        状况 R_386_32:
	    /* This relocations shouldn't normally need GOT or PLT
	       slots 若 it weren't 循环 simplicity in the code generator.
	       See our caller 循环 comments.  */
            返回 AUTO_GOTPLT_ENTRY;

	状况 R_386_PC16:
	状况 R_386_PC32:
            返回 AUTO_GOTPLT_ENTRY;

	状况 R_386_GOTPC:
	状况 R_386_GOTOFF:
            返回 BUILD_GOT_ONLY;

	状况 R_386_GOT32:
	状况 R_386_GOT32X:
	状况 R_386_PLT32:
            返回 ALWAYS_GOTPLT_ENTRY;
    }

    tcc_error ("Unknown relocation type: %d", reloc_type);
    返回 -1;
}

ST_FUNC 无符号 create_plt_entry(TCCState *s1, 无符号 got_offset, 结构体 sym_attr *attr)
{
    Section *plt = s1->plt;
    uint8_t *p;
    整 modrm;
    无符号 plt_offset, relofs;

    /* on i386 若 we build a DLL, we add a %ebx offset */
    若 (s1->output_type == TCC_OUTPUT_DLL)
        modrm = 0xa3;
    反之
        modrm = 0x25;

    /* empty PLT: create PLT0 entry that pushes the library identifier
       (GOT + PTR_SIZE) and jumps to ld.so resolution routine
       (GOT + 2 * PTR_SIZE) */
    若 (plt->data_offset == 0) {
        p = section_ptr_add(plt, 16);
        p[0] = 0xff; /* pushl got + PTR_SIZE */
        p[1] = modrm + 0x10;
        write32le(p + 2, PTR_SIZE);
        p[6] = 0xff; /* jmp *(got + PTR_SIZE * 2) */
        p[7] = modrm;
        write32le(p + 8, PTR_SIZE * 2);
    }
    plt_offset = plt->data_offset;

    /* The PLT slot refers to the relocation entry it needs via offset.
       The reloc entry is created below, so its offset is the current
       data_offset */
    relofs = s1->got->reloc ? s1->got->reloc->data_offset : 0;

    /* Jump to GOT entry where ld.so initially put the address of ip + 4 */
    p = section_ptr_add(plt, 16);
    p[0] = 0xff; /* jmp *(got + x) */
    p[1] = modrm;
    write32le(p + 2, got_offset);
    p[6] = 0x68; /* push $xxx */
    write32le(p + 7, relofs);
    p[11] = 0xe9; /* jmp plt_start */
    write32le(p + 12, -(plt->data_offset));
    返回 plt_offset;
}

/* relocate the PLT: compute addresses and offsets in the PLT now that final
   address 循环 PLT and GOT are known (see fill_program_header) */
ST_FUNC 空 relocate_plt(TCCState *s1)
{
    uint8_t *p, *p_end;

    若 (!s1->plt)
      返回;

    p = s1->plt->data;
    p_end = p + s1->plt->data_offset;

    若 (p < p_end) {
        add32le(p + 2, s1->got->sh_addr);
        add32le(p + 8, s1->got->sh_addr);
        p += 16;
        重复 (p < p_end) {
            add32le(p + 2, s1->got->sh_addr);
            p += 16;
        }
    }
}

静态 ElfW_Rel *qrel; /* ptr to next reloc entry reused */

空 relocate_init(Section *sr)
{
    qrel = (ElfW_Rel *) sr->data;
}

空 relocate(TCCState *s1, ElfW_Rel *rel, 整 type, 无符号 字符 *ptr, addr_t addr, addr_t val)
{
    整 sym_index, esym_index;

    sym_index = ELFW(R_SYM)(rel->r_info);

    岔路 (type) {
        状况 R_386_32:
            若 (s1->output_type == TCC_OUTPUT_DLL) {
                esym_index = s1->sym_attrs[sym_index].dyn_index;
                qrel->r_offset = rel->r_offset;
                若 (esym_index) {
                    qrel->r_info = ELFW(R_INFO)(esym_index, R_386_32);
                    qrel++;
                    返回;
                } 反之 {
                    qrel->r_info = ELFW(R_INFO)(0, R_386_RELATIVE);
                    qrel++;
                }
            }
            add32le(ptr, val);
            返回;
        状况 R_386_PC32:
            若 (s1->output_type == TCC_OUTPUT_DLL) {
                /* DLL relocation */
                esym_index = s1->sym_attrs[sym_index].dyn_index;
                若 (esym_index) {
                    qrel->r_offset = rel->r_offset;
                    qrel->r_info = ELFW(R_INFO)(esym_index, R_386_PC32);
                    qrel++;
                    返回;
                }
            }
            add32le(ptr, val - addr);
            返回;
        状况 R_386_PLT32:
            add32le(ptr, val - addr);
            返回;
        状况 R_386_GLOB_DAT:
        状况 R_386_JMP_SLOT:
            write32le(ptr, val);
            返回;
        状况 R_386_GOTPC:
            add32le(ptr, s1->got->sh_addr - addr);
            返回;
        状况 R_386_GOTOFF:
            add32le(ptr, val - s1->got->sh_addr);
            返回;
        状况 R_386_GOT32:
        状况 R_386_GOT32X:
            /* we load the got offset */
            add32le(ptr, s1->sym_attrs[sym_index].got_offset);
            返回;
        状况 R_386_16:
            若 (s1->output_format != TCC_OUTPUT_FORMAT_BINARY) {
            output_file:
                tcc_error("can only produce 16-bit binary files");
            }
            write16le(ptr, read16le(ptr) + val);
            返回;
        状况 R_386_PC16:
            若 (s1->output_format != TCC_OUTPUT_FORMAT_BINARY)
                跳转 output_file;
            write16le(ptr, read16le(ptr) + val - addr);
            返回;
        状况 R_386_RELATIVE:
            /* 当 nothing */
            返回;
        状况 R_386_COPY:
            /* This relocation must copy initialized data from the library
            to the program .bss segment. Currently made like 循环 ARM
            (to remove noise of 默认 状况). Is this true?
            */
            返回;
        默认:
            fprintf(stderr,"FIXME: handle reloc type %d at %x [%p] to %x\n",
                type, (无符号)addr, ptr, (无符号)val);
            返回;
    }
}

#终若 /* !TARGET_DEFS_ONLY */
