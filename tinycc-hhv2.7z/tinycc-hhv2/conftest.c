#包括 <stdio.h>

/* 定义 architecture */
#若 已定义(__i386__) || 已定义 _M_IX86
# 定义 TRIPLET_ARCH "i386"
#反之若 已定义(__x86_64__) || 已定义 _M_AMD64
# 定义 TRIPLET_ARCH "x86_64"
#反之若 已定义(__arm__)
# 定义 TRIPLET_ARCH "arm"
#反之若 已定义(__aarch64__)
# 定义 TRIPLET_ARCH "aarch64"
#反之
# 定义 TRIPLET_ARCH "unknown"
#终若

/* 定义 OS */
#若 已定义 (__linux__)
# 定义 TRIPLET_OS "linux"
#反之若 已定义 (__FreeBSD__) || 已定义 (__FreeBSD_kernel__)
# 定义 TRIPLET_OS "kfreebsd"
#反之若 已定义 _WIN32
# 定义 TRIPLET_OS "win32"
#反之若 !已定义 (__GNU__)
# 定义 TRIPLET_OS "unknown"
#终若

/* 定义 calling convention and ABI */
#若 已定义 (__ARM_EABI__)
# 若 已定义 (__ARM_PCS_VFP)
#  定义 TRIPLET_ABI "gnueabihf"
# 反之
#  定义 TRIPLET_ABI "gnueabi"
# 终若
#反之
# 定义 TRIPLET_ABI "gnu"
#终若

#若 已定义 _WIN32
# 定义 TRIPLET TRIPLET_ARCH "-" TRIPLET_OS
#反之若 已定义 __GNU__
# 定义 TRIPLET TRIPLET_ARCH "-" TRIPLET_ABI
#反之
# 定义 TRIPLET TRIPLET_ARCH "-" TRIPLET_OS "-" TRIPLET_ABI
#终若

#若 已定义(_WIN32)
整 _CRT_glob = 0;
#终若

整 main(整 argc, 字符 *argv[])
{
    岔路(argc == 2 ? argv[1][0] : 0) {
        状况 'b':
        {
            易变 无符号 foo = 0x01234567;
            puts(*(无符号 字符*)&foo == 0x67 ? "no" : "yes");
            打断;
        }
#若定义 __GNUC__
        状况 'm':
            printf("%d\n", __GNUC_MINOR__);
            打断;
        状况 'v':
            printf("%d\n", __GNUC__);
            打断;
#反之若 已定义 __TINYC__
        状况 'v':
            puts("0");
            打断;
        状况 'm':
            printf("%d\n", __TINYC__);
            打断;
#反之
        状况 'm':
        状况 'v':
            puts("0");
            打断;
#终若
        状况 't':
            puts(TRIPLET);
            打断;

        默认:
            打断;
    }
    返回 0;
}
