#若定义 TARGET_DEFS_ONLY

#定义 EM_TCC_TARGET EM_C60

/* relocation type 循环 32 bit data relocation */
#定义 R_DATA_32   R_C60_32
#定义 R_DATA_PTR  R_C60_32
#定义 R_JMP_SLOT  R_C60_JMP_SLOT
#定义 R_GLOB_DAT  R_C60_GLOB_DAT
#定义 R_COPY      R_C60_COPY
#定义 R_RELATIVE  R_C60_RELATIVE

#定义 R_NUM       R_C60_NUM

#定义 ELF_START_ADDR 0x00000400
#定义 ELF_PAGE_SIZE  0x1000

#定义 PCRELATIVE_DLLPLT 0
#定义 RELOCATE_DLLPLT 0

#反之 /* !TARGET_DEFS_ONLY */

#包括 "tcc.h"

/* Returns 1 循环 a code relocation, 0 循环 a data relocation. 循环 unknown
   relocations, returns -1. */
整 code_reloc (整 reloc_type)
{
    岔路 (reloc_type) {
        状况 R_C60_32:
	状况 R_C60LO16:
	状况 R_C60HI16:
        状况 R_C60_GOT32:
        状况 R_C60_GOTOFF:
        状况 R_C60_GOTPC:
        状况 R_C60_COPY:
            返回 0;

        状况 R_C60_PLT32:
            返回 1;
    }

    tcc_error ("Unknown relocation type: %d", reloc_type);
    返回 -1;
}

/* Returns an enumerator to describe whether and when the relocation needs a
   GOT and/or PLT entry to be created. See tcc.h 循环 a description of the
   different values. */
整 gotplt_entry_type (整 reloc_type)
{
    岔路 (reloc_type) {
        状况 R_C60_32:
	状况 R_C60LO16:
	状况 R_C60HI16:
        状况 R_C60_COPY:
            返回 NO_GOTPLT_ENTRY;

        状况 R_C60_GOTOFF:
        状况 R_C60_GOTPC:
            返回 BUILD_GOT_ONLY;

        状况 R_C60_PLT32:
        状况 R_C60_GOT32:
            返回 ALWAYS_GOTPLT_ENTRY;
    }

    tcc_error ("Unknown relocation type: %d", reloc_type);
    返回 -1;
}

ST_FUNC 无符号 create_plt_entry(TCCState *s1, 无符号 got_offset, 结构体 sym_attr *attr)
{
    tcc_error("C67 got not implemented");
    返回 0;
}

/* relocate the PLT: compute addresses and offsets in the PLT now that final
   address 循环 PLT and GOT are known (see fill_program_header) */
ST_FUNC 空 relocate_plt(TCCState *s1)
{
    uint8_t *p, *p_end;

    若 (!s1->plt)
      返回;

    p = s1->plt->data;
    p_end = p + s1->plt->data_offset;

    若 (p < p_end) {
        /* XXX: TODO */
        重复 (p < p_end) {
            /* XXX: TODO */
        }
   }
}

空 relocate_init(Section *sr) {}

空 relocate(TCCState *s1, ElfW_Rel *rel, 整 type, 无符号 字符 *ptr, addr_t addr, addr_t val)
{
    岔路(type) {
        状况 R_C60_32:
            *(整 *)ptr += val;
            打断;
        状况 R_C60LO16:
            {
                uint32_t orig;

                /* put the low 16 bits of the absolute address add to what is
                   already there */
                orig  =   ((*(整 *)(ptr  )) >> 7) & 0xffff;
                orig |=  (((*(整 *)(ptr+4)) >> 7) & 0xffff) << 16;

                /* patch both at once - assumes always in pairs Low - High */
                *(整 *) ptr    = (*(整 *) ptr    & (~(0xffff << 7)) ) |
                                   (((val+orig)      & 0xffff) << 7);
                *(整 *)(ptr+4) = (*(整 *)(ptr+4) & (~(0xffff << 7)) ) |
                                  ((((val+orig)>>16) & 0xffff) << 7);
            }
            打断;
        状况 R_C60HI16:
            打断;
        默认:
            fprintf(stderr,"FIXME: handle reloc type %x at %x [%p] to %x\n",
                    type, (无符号) addr, ptr, (无符号) val);
            打断;
    }
}

#终若 /* !TARGET_DEFS_ONLY */
