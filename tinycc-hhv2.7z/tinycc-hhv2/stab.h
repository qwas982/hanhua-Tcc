#若未定义 __GNU_STAB__

/* Indicate the GNU stab.h is in use.  */

#定义 __GNU_STAB__

#定义 __define_stab(NAME, CODE, STRING) NAME=CODE,

枚举 __stab_debug_code
{
#包括 "stab.def"
LAST_UNUSED_STAB_CODE
};

#取消定义 __define_stab

#终若 /* __GNU_STAB_ */
